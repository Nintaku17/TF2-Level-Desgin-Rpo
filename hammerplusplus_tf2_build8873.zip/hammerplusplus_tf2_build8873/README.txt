--- Install instructions ---
This build of Hammer++ only works for the following:
- Team Fortress 2
- Counter Strike Source
- Day of Defeat Source
- Half Life 2 Deathmatch
- Any 64-bit game based on latest Source SDK engine

32-bit is no longer supported.

1. Find where the game/sourcemod is installed (the example uses Team Fortress 2)

2. Copy over everything inside this download's "bin" folder into TF2's "bin" folder.
	Your paths should look like this:
	<steam install location>/steamapps/common/Team Fortress 2/bin/x64/hammerplusplus.exe
	<steam install location>/steamapps/common/Team Fortress 2/bin/x64/hammerplusplus/<other files>

3. Launch the Hammer++ exe, and you are done!

4. (Sourcemods only) the -game parameter is not required as it's automatically added
	This means you don't need to do the shortcut method anymore, simply start the hammerplusplus.exe

-- Troublshooting --
If you get an application error with code 0xc0000007b, you installed the files into the wrong 32-bit folder.
Since the 64-bit update, the files must now go into the "x64" folder inside "bin".

If you had a previous install before the 64-bit update, your settings and configs will be reset. 
This is because the files now exist in the new "x64" folder. 
You may copy over the hammerplusplus_settings.ini and hammerplusplus_sequences.cfg from the old "hammerplusplus" folder over to the new one inside "x64".

--- Other Information ---
Hammer++ does not use the GameConfig.txt, instead it uses its own GameConfig.txt located in the hammerplusplus subfolder. 
If not found, it copies the normal game configuration.
Keep this in mind when following any tutorials that might require the GameConfig.txt to be edited.

HLMV++ comes bundled with the download, it is optional and not required for Hammer++ to work.

--- Uninstallation ---
To uninstall, simply delete the hammerplusplus.exe
You can also optionally delete the hammerplusplus folder, but this will remove all saved settings for Hammer++.